void lidar_Init(void);
void outputLidarData(int stepCounter, double xDistMM, double degPerStep);
void PortG_Init(void);
void VL53L1X_XSHUT(void);
